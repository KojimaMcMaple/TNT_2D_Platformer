#pragma once

enum LevelId {
	CHURCH,
	CASTLE,
	NUM_OF_LEVEL_IDS
};