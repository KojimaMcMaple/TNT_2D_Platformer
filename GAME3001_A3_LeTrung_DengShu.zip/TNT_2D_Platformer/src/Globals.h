#pragma once

class Globals {
public:
	static int sFps;
	static int sDelayTime;
	static int sWindowWidth;
	static int sWindowHeight;
	static float sGravity;
	static float sJumpForce;
};