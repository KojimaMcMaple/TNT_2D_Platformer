#pragma once
#ifndef __TILE_NEIGHBOUR__
#define __TILE_NEIGHBOUR__
enum TileNeighbour
{
	UP,
	DOWN,
	LEFT,
	RIGHT,
	NUM_OF_NEIGHBOURS
};
#endif /* defined (__TILE_NEIGHBOUR__) */