#pragma once
//#ifndef __ANIM_STATES__
//#define __ANIM_STATES__

enum EnemyType {
	SKELETON_SWORD,
	NUM_OF_ENEMY_TYPES
};

//#endif /* defined (__STEERING_STATE__) */