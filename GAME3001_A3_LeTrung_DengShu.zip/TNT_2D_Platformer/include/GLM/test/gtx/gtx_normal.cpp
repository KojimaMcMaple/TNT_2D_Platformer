#include <glm/gtx/normal.hpp>

int main()
{
	int Error(0);

	return Error;
}
