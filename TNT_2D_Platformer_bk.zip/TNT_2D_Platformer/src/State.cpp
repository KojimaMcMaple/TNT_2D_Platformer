#include "State.h"
#include "Engine.h"

State::State(){}
State::~State(){}

void State::Render() {
	//SDL_RenderClear(Engine::Instance().GetRenderer()); // Clear the screen with the draw color.
	//SDL_RenderPresent(Engine::Instance().GetRenderer()));
}

